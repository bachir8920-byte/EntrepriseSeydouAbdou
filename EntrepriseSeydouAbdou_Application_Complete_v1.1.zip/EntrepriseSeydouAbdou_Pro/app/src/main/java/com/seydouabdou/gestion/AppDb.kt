package com.seydouabdou.gestion

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Material(val id:Int,val name:String,val stock:Int,val price:Long,val low:Int)
data class Person(val id:Int,val name:String,val phone:String,val address:String)
data class SaleLine(val materialId:Int,val qty:Int,val price:Long)
data class SaleSummary(val id:Int,val invoice:String,val client:String,val total:Long,val date:String)
data class PurchaseSummary(val id:Int,val reference:String,val supplier:String,val total:Long,val date:String)
data class ExpenseSummary(val id:Int,val description:String,val category:String,val amount:Long,val date:String)

class AppDb(ctx: Context) : SQLiteOpenHelper(ctx, "seydou_abdou.db", null, 2) {
    private val names = listOf(
        "Ciments","Tubes carrés","Tubes rondes","Peintures","Colorant","Chaise",
        "Lit picolé","Miroirs","Compteur d’eau","Tuyaux PVC","Galvanisé","Fils de fer",
        "Pinceaux","Briques","Vernis","Fer de 8 éco","Fer de 10 éco","Fer de 12 éco",
        "Fer de 8 normalisé","Fer de 10 normalisé","Fer de 12 normalisé","Chevron"
    )

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE materials(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL,stock INTEGER NOT NULL DEFAULT 0,price INTEGER NOT NULL DEFAULT 0,low INTEGER NOT NULL DEFAULT 10)")
        db.execSQL("CREATE TABLE clients(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,address TEXT,created INTEGER)")
        db.execSQL("CREATE TABLE suppliers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,address TEXT,created INTEGER)")
        db.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice TEXT UNIQUE,client_name TEXT,client_phone TEXT,client_address TEXT,total INTEGER,created INTEGER,cancelled INTEGER DEFAULT 0)")
        db.execSQL("CREATE TABLE sale_items(id INTEGER PRIMARY KEY AUTOINCREMENT,sale_id INTEGER,material_id INTEGER,qty INTEGER,price INTEGER,total INTEGER)")
        db.execSQL("CREATE TABLE purchases(id INTEGER PRIMARY KEY AUTOINCREMENT,reference TEXT UNIQUE,supplier_name TEXT,total INTEGER,created INTEGER)")
        db.execSQL("CREATE TABLE purchase_items(id INTEGER PRIMARY KEY AUTOINCREMENT,purchase_id INTEGER,material_id INTEGER,qty INTEGER,price INTEGER,total INTEGER)")
        db.execSQL("CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT,description TEXT,category TEXT,amount INTEGER,created INTEGER)")
        db.execSQL("CREATE TABLE stock_moves(id INTEGER PRIMARY KEY AUTOINCREMENT,material_id INTEGER,type TEXT,qty INTEGER,note TEXT,created INTEGER)")
        names.forEach { db.execSQL("INSERT INTO materials(name,stock,price,low) VALUES(?,?,?,?)", arrayOf(it,100,0,10)) }
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("CREATE TABLE IF NOT EXISTS purchases(id INTEGER PRIMARY KEY AUTOINCREMENT,reference TEXT UNIQUE,supplier_name TEXT,total INTEGER,created INTEGER)")
            db.execSQL("CREATE TABLE IF NOT EXISTS purchase_items(id INTEGER PRIMARY KEY AUTOINCREMENT,purchase_id INTEGER,material_id INTEGER,qty INTEGER,price INTEGER,total INTEGER)")
            db.execSQL("CREATE TABLE IF NOT EXISTS stock_moves(id INTEGER PRIMARY KEY AUTOINCREMENT,material_id INTEGER,type TEXT,qty INTEGER,note TEXT,created INTEGER)")
            db.execSQL("ALTER TABLE sales ADD COLUMN cancelled INTEGER DEFAULT 0")
        }
    }

    private fun now() = System.currentTimeMillis()
    private fun date(ms:Long) = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(Date(ms))

    fun materials(): List<Material> {
        val out=mutableListOf<Material>()
        readableDatabase.rawQuery("SELECT id,name,stock,price,low FROM materials ORDER BY name",null).use {
            while(it.moveToNext()) out.add(Material(it.getInt(0),it.getString(1),it.getInt(2),it.getLong(3),it.getInt(4)))
        }
        return out
    }
    fun material(id:Int)=materials().first{it.id==id}

    fun updateMaterial(id:Int,name:String,price:Long,low:Int) {
        writableDatabase.execSQL("UPDATE materials SET name=?,price=?,low=? WHERE id=?",arrayOf(name,price,low,id))
    }
    fun lowStockCount()=materials().count{it.stock<=it.low}

    fun addStock(id:Int,qty:Int,price:Long,note:String="Entrée manuelle") {
        val db=writableDatabase; db.beginTransaction()
        try {
            db.execSQL("UPDATE materials SET stock=stock+?,price=? WHERE id=?",arrayOf(qty,price,id))
            db.execSQL("INSERT INTO stock_moves(material_id,type,qty,note,created) VALUES(?,?,?,?,?)",arrayOf(id,"ENTREE",qty,note,now()))
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun removeStock(id:Int,qty:Int,note:String="Sortie manuelle") {
        val db=writableDatabase
        val m=material(id); require(qty>0 && qty<=m.stock){"Stock insuffisant"}
        db.beginTransaction()
        try {
            db.execSQL("UPDATE materials SET stock=stock-? WHERE id=?",arrayOf(qty,id))
            db.execSQL("INSERT INTO stock_moves(material_id,type,qty,note,created) VALUES(?,?,?,?,?)",arrayOf(id,"SORTIE",qty,note,now()))
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun addClient(n:String,p:String,a:String)=insertPerson("clients",n,p,a)
    fun addSupplier(n:String,p:String,a:String)=insertPerson("suppliers",n,p,a)
    private fun insertPerson(table:String,n:String,p:String,a:String) {
        writableDatabase.execSQL("INSERT INTO $table(name,phone,address,created) VALUES(?,?,?,?)",arrayOf(n.trim(),p.trim(),a.trim(),now()))
    }
    fun clients()=people("clients")
    fun suppliers()=people("suppliers")
    private fun people(table:String):List<Person>{
        val o=mutableListOf<Person>()
        readableDatabase.rawQuery("SELECT id,name,phone,address FROM $table ORDER BY name",null).use{
            while(it.moveToNext()) o.add(Person(it.getInt(0),it.getString(1),it.getString(2)?:"",it.getString(3)?:""))
        };return o
    }

    fun addExpense(d:String,cat:String,a:Long) {
        writableDatabase.execSQL("INSERT INTO expenses(description,category,amount,created) VALUES(?,?,?,?)",arrayOf(d,cat,a,now()))
    }

    fun createSale(client:String,phone:String,address:String,items:List<SaleLine>,total:Long):String {
        val db=writableDatabase; db.beginTransaction()
        try {
            items.forEach { require(it.qty>0){"Quantité invalide"}; require(it.qty<=material(it.materialId).stock){"Stock insuffisant pour ${material(it.materialId).name}"} }
            val invoice="#V"+SimpleDateFormat("yyyyMMdd-HHmmss",Locale.US).format(Date())
            val id=db.compileStatement("INSERT INTO sales(invoice,client_name,client_phone,client_address,total,created,cancelled) VALUES(?,?,?,?,?,?,0)")
                .apply { bindString(1,invoice);bindString(2,client);bindString(3,phone);bindString(4,address);bindLong(5,total);bindLong(6,now()) }.executeInsert()
            items.forEach {
                db.execSQL("INSERT INTO sale_items(sale_id,material_id,qty,price,total) VALUES(?,?,?,?,?)",arrayOf(id,it.materialId,it.qty,it.price,it.qty*it.price))
                db.execSQL("UPDATE materials SET stock=stock-? WHERE id=?",arrayOf(it.qty,it.materialId))
                db.execSQL("INSERT INTO stock_moves(material_id,type,qty,note,created) VALUES(?,?,?,?,?)",arrayOf(it.materialId,"VENTE",-it.qty,invoice,now()))
            }
            db.setTransactionSuccessful();return invoice
        } finally { db.endTransaction() }
    }

    fun sales(limit:Int=100,query:String=""):List<SaleSummary>{
        val o=mutableListOf<SaleSummary>()
        val q="%${query.trim()}%"
        readableDatabase.rawQuery("SELECT id,invoice,client_name,total,created FROM sales WHERE cancelled=0 AND (invoice LIKE ? OR client_name LIKE ?) ORDER BY created DESC LIMIT ?",arrayOf(q,q,limit.toString())).use{
            while(it.moveToNext()) o.add(SaleSummary(it.getInt(0),it.getString(1),it.getString(2)?:"Client",it.getLong(3),date(it.getLong(4))))
        };return o
    }
    fun saleItems(saleId:Int):List<SaleLine>{
        val o=mutableListOf<SaleLine>()
        readableDatabase.rawQuery("SELECT material_id,qty,price FROM sale_items WHERE sale_id=?",arrayOf(saleId.toString())).use{
            while(it.moveToNext())o.add(SaleLine(it.getInt(0),it.getInt(1),it.getLong(2)))
        };return o
    }
    fun cancelSale(saleId:Int) {
        val db=writableDatabase;db.beginTransaction()
        try {
            saleItems(saleId).forEach { line ->
                db.execSQL("UPDATE materials SET stock=stock+? WHERE id=?",arrayOf(line.qty,line.materialId))
                db.execSQL("INSERT INTO stock_moves(material_id,type,qty,note,created) VALUES(?,?,?,?,?)",arrayOf(line.materialId,"ANNULATION",line.qty,"Vente #$saleId",now()))
            }
            db.execSQL("UPDATE sales SET cancelled=1 WHERE id=?",arrayOf(saleId))
            db.setTransactionSuccessful()
        } finally {db.endTransaction()}
    }

    fun addPurchase(supplier:String,items:List<SaleLine>):String {
        val total=items.sumOf{it.qty*it.price}; val db=writableDatabase;db.beginTransaction()
        try {
            val ref="#A"+SimpleDateFormat("yyyyMMdd-HHmmss",Locale.US).format(Date())
            val id=db.compileStatement("INSERT INTO purchases(reference,supplier_name,total,created) VALUES(?,?,?,?)").apply{bindString(1,ref);bindString(2,supplier);bindLong(3,total);bindLong(4,now())}.executeInsert()
            items.forEach {
                db.execSQL("INSERT INTO purchase_items(purchase_id,material_id,qty,price,total) VALUES(?,?,?,?,?)",arrayOf(id,it.materialId,it.qty,it.price,it.qty*it.price))
                db.execSQL("UPDATE materials SET stock=stock+?,price=? WHERE id=?",arrayOf(it.qty,it.price,it.materialId))
                db.execSQL("INSERT INTO stock_moves(material_id,type,qty,note,created) VALUES(?,?,?,?,?)",arrayOf(it.materialId,"ACHAT",it.qty,ref,now()))
            }
            db.setTransactionSuccessful();return ref
        }finally{db.endTransaction()}
    }

    fun purchases(limit:Int=100):List<PurchaseSummary>{
        val o=mutableListOf<PurchaseSummary>()
        readableDatabase.rawQuery("SELECT id,reference,supplier_name,total,created FROM purchases ORDER BY created DESC LIMIT ?",arrayOf(limit.toString())).use{
            while(it.moveToNext())o.add(PurchaseSummary(it.getInt(0),it.getString(1),it.getString(2),it.getLong(3),date(it.getLong(4))))
        };return o
    }
    fun expenses(limit:Int=100):List<ExpenseSummary>{
        val o=mutableListOf<ExpenseSummary>()
        readableDatabase.rawQuery("SELECT id,description,category,amount,created FROM expenses ORDER BY created DESC LIMIT ?",arrayOf(limit.toString())).use{
            while(it.moveToNext())o.add(ExpenseSummary(it.getInt(0),it.getString(1),it.getString(2),it.getLong(3),date(it.getLong(4))))
        };return o
    }

    private fun sumSince(table:String,col:String,sinceMs:Long):Long {
        readableDatabase.rawQuery("SELECT COALESCE(SUM($col),0) FROM $table WHERE created>=?",arrayOf(sinceMs.toString())).use{it.moveToFirst();return it.getLong(0)}
    }
    fun todaySales()=sumSince("sales","total",startOfDay())
    fun monthSales()=sumSince("sales","total",startOfMonth())
    fun todayExpenses()=sumSince("expenses","amount",startOfDay())
    fun monthExpenses()=sumSince("expenses","amount",startOfMonth())
    fun monthPurchases()=sumSince("purchases","total",startOfMonth())

    private fun startOfDay():Long { val c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);return c.timeInMillis }
    private fun startOfMonth():Long { val c=Calendar.getInstance();c.set(Calendar.DAY_OF_MONTH,1);c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);return c.timeInMillis }

    fun stockMoves(limit:Int=100):List<String>{
        val out=mutableListOf<String>()
        readableDatabase.rawQuery("SELECT m.name,s.type,s.qty,s.note,s.created FROM stock_moves s JOIN materials m ON m.id=s.material_id ORDER BY s.created DESC LIMIT ?",arrayOf(limit.toString())).use{
            while(it.moveToNext())out.add("${it.getString(0)} • ${it.getString(1)} • ${it.getInt(2)} • ${it.getString(3)} • ${date(it.getLong(4))}")
        };return out
    }

    fun exportJson():String {
        val root=JSONObject()
        root.put("company","ENTREPRISE SEYDOU ABDOU");root.put("location","Guéchémé, Niger");root.put("exportedAt",Date().toString())
        val ms=JSONArray();materials().forEach{m->ms.put(JSONObject().apply{put("id",m.id);put("name",m.name);put("stock",m.stock);put("price",m.price);put("low",m.low)})};root.put("materials",ms)
        val cls=JSONArray();clients().forEach{p->cls.put(JSONObject().apply{put("name",p.name);put("phone",p.phone);put("address",p.address)})};root.put("clients",cls)
        return root.toString(2)
    }
}
