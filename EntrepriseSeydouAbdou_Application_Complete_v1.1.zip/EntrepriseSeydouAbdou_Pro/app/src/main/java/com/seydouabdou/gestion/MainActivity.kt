package com.seydouabdou.gestion

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.view.*
import android.widget.*
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var db:AppDb
    private lateinit var root:LinearLayout
    private val bg=Color.rgb(9,13,22);private val card=Color.rgb(20,29,45)
    private val white=Color.rgb(248,250,252);private val muted=Color.rgb(148,163,184)
    private val cyan=Color.rgb(6,182,212);private val blue=Color.rgb(59,130,246)
    private val gold=Color.rgb(245,158,11);private val green=Color.rgb(34,197,94);private val red=Color.rgb(239,68,68)

    override fun onCreate(b:Bundle?){super.onCreate(b);db=AppDb(this);lock()}
    private fun lock(){val p=getSharedPreferences("settings",0);if(p.getString("pin",null)==null)pinSetup() else pinEntry()}

    private fun base(title:String):LinearLayout{
        root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(bg);setPadding(16,14,16,8)}
        val h=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val logo=ImageView(this).apply{setImageResource(R.drawable.logo);layoutParams=LinearLayout.LayoutParams(50,50)}
        h.addView(logo)
        val t=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(10,0,0,0)}
        t.addView(tv("ENTREPRISE SEYDOU ABDOU",17,white,true));t.addView(tv(title,12,muted))
        h.addView(t,LinearLayout.LayoutParams(0,-2,1f));root.addView(h)
        val s=ScrollView(this);val c=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,12,0,78)};s.addView(c)
        root.addView(s,LinearLayout.LayoutParams(-1,0,1f));setContentView(root);return c
    }
    private fun tv(x:String,size:Float,color:Int,bold:Boolean=false)=TextView(this).apply{text=x;textSize=size;setTextColor(color);if(bold)setTypeface(null,Typeface.BOLD)}
    private fun btn(x:String,a:()->Unit)=Button(this).apply{text=x;textSize=13f;isAllCaps=false;setTextColor(white);setBackgroundColor(card);setOnClickListener{a()};minHeight=50}
    private fun input(h:String,v:String="")=EditText(this).apply{hint=h;setText(v);setTextColor(white);setHintTextColor(muted);setBackgroundColor(card);setPadding(14,6,14,6);layoutParams=LinearLayout.LayoutParams(-1,52).apply{setMargins(0,5,0,5)}}
    private fun title(x:String)=tv(x,16,white,true).apply{setPadding(0,10,0,5)}
    private fun nav(){
        val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;setBackgroundColor(Color.rgb(12,18,30))}
        val labels=listOf("⌂\nAccueil","🧾\nVente","📦\nStock","👥\nClients","☰\nPlus")
        labels.forEachIndexed{i,x->bar.addView(Button(this).apply{text=x;textSize=10f;isAllCaps=false;setTextColor(white);setBackgroundColor(Color.TRANSPARENT);setOnClickListener{when(i){0->home();1->sale();2->stock();3->clients();4->more()}}},LinearLayout.LayoutParams(0,62,1f))}
        root.addView(bar)
    }
    private fun money(v:Long)=String.format(Locale.US,"%,d",v).replace(',',' ')
    private fun toast(x:String)=Toast.makeText(this,x,Toast.LENGTH_SHORT).show()
    private fun hash(x:String)=MessageDigest.getInstance("SHA-256").digest(x.toByteArray()).joinToString(""){"%02x".format(it)}

    private fun home(){
        val c=base("Tableau de bord")
        c.addView(title("📊 Aujourd'hui"))
        c.addView(tv("Ventes : ${money(db.todaySales())} FCFA",20,cyan,true))
        c.addView(tv("Dépenses : ${money(db.todayExpenses())} FCFA",15,muted))
        c.addView(tv("Bénéfice estimé : ${money(db.todaySales()-db.todayExpenses())} FCFA",17,green,true))
        c.addView(tv("⚠️ Stock faible : ${db.lowStockCount()} article(s)",14,if(db.lowStockCount()>0)gold else green,true))
        c.addView(title("⚡ Actions rapides"))
        c.addView(btn("🧾 Nouvelle vente"){sale()});c.addView(btn("📥 Nouvel achat / entrée stock"){purchase()})
        c.addView(btn("💸 Nouvelle dépense"){expenseForm()});c.addView(btn("👥 Nouveau client"){clientForm()})
        c.addView(title("🧾 Dernières ventes"))
        db.sales(8).forEach{s->c.addView(tv("${s.invoice} • ${s.client} • ${money(s.total)} FCFA • ${s.date}",13,white))}
        nav()
    }

    private fun sale(){
        val c=base("Nouvelle vente")
        val n=input("Nom du client","Client Anonyme");val ph=input("Téléphone","N/A");val ad=input("Localisation","Guéchémé")
        c.addView(title("👤 Client"));c.addView(n);c.addView(ph);c.addView(ad);c.addView(title("📦 Articles"))
        val rows=mutableListOf<Triple<Int,EditText,EditText>>()
        db.materials().forEach{m->
            val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(10,8,10,8);setBackgroundColor(card)}
            box.addView(tv("${m.name} • Stock ${m.stock}",14,white,true))
            val q=input("Quantité","0");val p=input("Prix unitaire FCFA",if(m.price>0)m.price.toString() else "0");box.addView(q);box.addView(p)
            c.addView(box,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,4,0,4)});rows.add(Triple(m.id,q,p))
        }
        c.addView(btn("✅ ENREGISTRER LA VENTE + REÇU"){val items=rows.mapNotNull{(id,q,p)->val qty=q.text.toString().toIntOrNull()?:0;val pr=p.text.toString().toLongOrNull()?:0;if(qty>0)SaleLine(id,qty,pr)else null}
            if(items.isEmpty()){toast("Ajoutez un article");return@btn};try{val total=items.sumOf{it.qty*it.price};val inv=db.createSale(n.text.toString(),ph.text.toString(),ad.text.toString(),items,total);pdfReceipt(inv,n.text.toString(),items,total);home()}catch(e:Exception){toast(e.message?:"Erreur")}})
        nav()
    }

    private fun stock(){
        val c=base("Stock & inventaire")
        c.addView(btn("➕ Entrée de stock"){purchase()})
        c.addView(btn("🛠️ Ajustement / sortie"){adjustment()})
        c.addView(btn("📜 Mouvements de stock"){stockMoves()})
        db.materials().forEach{m->val b=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(12,9,12,9);setBackgroundColor(card)}
            b.addView(tv(m.name,15,white,true));b.addView(tv("Stock: ${m.stock}  • Seuil: ${m.low}  • Prix: ${money(m.price)} FCFA",13,if(m.stock<=m.low)gold else muted));c.addView(b,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,4,0,4)})}
        nav()
    }

    private fun purchase(){
        val c=base("Achat / entrée de stock");val sup=input("Fournisseur","");c.addView(title("🤝 Fournisseur"));c.addView(sup);c.addView(title("📦 Articles"))
        val rows=mutableListOf<Triple<Int,EditText,EditText>>()
        db.materials().forEach{m->val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(10,6,10,6);setBackgroundColor(card)}
            box.addView(tv(m.name,14,white,true));val q=input("Quantité achetée","0");val p=input("Prix d'achat unitaire FCFA",if(m.price>0)m.price.toString() else "0");box.addView(q);box.addView(p);c.addView(box,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,3,0,3)});rows.add(Triple(m.id,q,p))}
        c.addView(btn("💾 ENREGISTRER L'ACHAT"){val items=rows.mapNotNull{(id,q,p)->val qty=q.text.toString().toIntOrNull()?:0;val pr=p.text.toString().toLongOrNull()?:0;if(qty>0)SaleLine(id,qty,pr)else null};if(items.isEmpty()){toast("Ajoutez un article");return@btn};try{db.addPurchase(sup.text.toString().ifBlank{"Fournisseur inconnu"},items);toast("Achat enregistré");stock()}catch(e:Exception){toast(e.message?:"Erreur")}})
        nav()
    }

    private fun adjustment(){
        val c=base("Ajustement de stock");val ms=db.materials();val sp=Spinner(this);sp.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,ms.map{it.name});val q=input("Quantité","0");val note=input("Motif","Correction inventaire")
        c.addView(sp);c.addView(q);c.addView(note);c.addView(btn("➖ Retirer du stock"){try{db.removeStock(ms[sp.selectedItemPosition].id,q.text.toString().toInt(),note.text.toString());toast("Stock corrigé");stock()}catch(e:Exception){toast(e.message?:"Erreur")}})
        nav()
    }
    private fun stockMoves(){
        val c=base("Mouvements de stock");db.stockMoves(150).forEach{c.addView(tv("• $it",13,white).apply{setPadding(0,5,0,5)})};nav()
    }

    private fun clients(){
        val c=base("Clients");c.addView(btn("➕ Ajouter"){clientForm()});db.clients().forEach{c.addView(tv("${it.name}\n${it.phone} • ${it.address}",14,white,true).apply{setPadding(12,10,12,10);setBackgroundColor(card)})};nav()
    }
    private fun clientForm(){
        val c=base("Nouveau client");val n=input("Nom");val p=input("Téléphone");val a=input("Localisation");c.addView(n);c.addView(p);c.addView(a);c.addView(btn("💾 Enregistrer"){if(n.text.isBlank()){toast("Nom obligatoire");return@btn};db.addClient(n.text.toString(),p.text.toString(),a.text.toString());clients()});nav()
    }

    private fun more(){
        val c=base("Plus")
        c.addView(btn("📊 Rapports"){reports()});c.addView(btn("🧾 Historique des ventes"){salesHistory()})
        c.addView(btn("📥 Historique des achats"){purchasesHistory()});c.addView(btn("🤝 Fournisseurs"){suppliers()})
        c.addView(btn("💸 Dépenses"){expensesHistory()});c.addView(btn("🔐 Modifier le PIN"){changePin()})
        c.addView(btn("💾 Exporter une sauvegarde"){exportBackup()});c.addView(btn("ℹ️ À propos"){about()});nav()
    }

    private fun salesHistory(){
        val c=base("Historique des ventes");val search=input("Rechercher facture ou client");c.addView(search)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};c.addView(box)
        fun refresh(){box.removeAllViews();db.sales(200,search.text.toString()).forEach{s->val b=Button(this).apply{text="${s.invoice} • ${s.client}\n${money(s.total)} FCFA • ${s.date}";isAllCaps=false;setTextColor(white);setBackgroundColor(card);setOnClickListener{saleDetails(s.id)}};box.addView(b,LinearLayout.LayoutParams(-1,68).apply{setMargins(0,4,0,4)})}}
        c.addView(btn("🔎 Rechercher"){refresh()});refresh();nav()
    }
    private fun saleDetails(id:Int){
        val c=base("Détail de la vente");val items=db.saleItems(id);var total=0L;items.forEach{val m=db.material(it.materialId);val t=it.qty*it.price;total+=t;c.addView(tv("${m.name} • ${it.qty} × ${money(it.price)} = ${money(t)} FCFA",14,white))}
        c.addView(tv("TOTAL : ${money(total)} FCFA",18,cyan,true));c.addView(btn("↩️ Annuler cette vente et remettre le stock"){try{db.cancelSale(id);toast("Vente annulée et stock restauré");salesHistory()}catch(e:Exception){toast(e.message?:"Erreur")}});nav()
    }

    private fun purchasesHistory(){val c=base("Historique des achats");db.purchases(150).forEach{c.addView(tv("${it.reference} • ${it.supplier}\n${money(it.total)} FCFA • ${it.date}",14,white,true).apply{setPadding(12,10,12,10);setBackgroundColor(card)})};nav()}
    private fun suppliers(){val c=base("Fournisseurs");c.addView(btn("➕ Ajouter"){supplierForm()});db.suppliers().forEach{c.addView(tv("${it.name}\n${it.phone} • ${it.address}",14,white,true).apply{setPadding(12,10,12,10);setBackgroundColor(card)})};nav()}
    private fun supplierForm(){val c=base("Nouveau fournisseur");val n=input("Nom");val p=input("Téléphone");val a=input("Adresse");c.addView(n);c.addView(p);c.addView(a);c.addView(btn("💾 Enregistrer"){db.addSupplier(n.text.toString(),p.text.toString(),a.text.toString());suppliers()});nav()}
    private fun expensesHistory(){val c=base("Dépenses");c.addView(btn("➕ Nouvelle dépense"){expenseForm()});db.expenses(150).forEach{c.addView(tv("${it.description} • ${it.category}\n${money(it.amount)} FCFA • ${it.date}",14,white,true).apply{setPadding(12,10,12,10);setBackgroundColor(card)})};nav()}
    private fun expenseForm(){val c=base("Nouvelle dépense");val d=input("Description");val cat=input("Catégorie","Général");val a=input("Montant FCFA","0");c.addView(d);c.addView(cat);c.addView(a);c.addView(btn("💾 Enregistrer"){val v=a.text.toString().toLongOrNull()?:0;if(v<=0){toast("Montant invalide");return@btn};db.addExpense(d.text.toString(),cat.text.toString(),v);expensesHistory()});nav()}

    private fun reports(){
        val c=base("Rapports & bénéfices")
        c.addView(title("📅 Aujourd'hui"));c.addView(tv("Ventes : ${money(db.todaySales())} FCFA",18,cyan,true));c.addView(tv("Dépenses : ${money(db.todayExpenses())} FCFA",15,muted));c.addView(tv("Bénéfice : ${money(db.todaySales()-db.todayExpenses())} FCFA",16,green,true))
        c.addView(title("🗓️ Ce mois"));c.addView(tv("Ventes : ${money(db.monthSales())} FCFA",18,cyan,true));c.addView(tv("Achats : ${money(db.monthPurchases())} FCFA",15,muted));c.addView(tv("Dépenses : ${money(db.monthExpenses())} FCFA",15,muted));c.addView(tv("Marge simplifiée : ${money(db.monthSales()-db.monthPurchases()-db.monthExpenses())} FCFA",17,green,true));nav()
    }

    private fun pinSetup(){val c=base("Sécurité");c.addView(tv("🔐 Créez votre PIN administrateur",20,white,true));val p=input("PIN à 4 chiffres");p.inputType=2;c.addView(p);c.addView(btn("Créer le PIN"){if(p.text.length!=4){toast("4 chiffres");return@btn};getSharedPreferences("settings",0).edit().putString("pin",hash(p.text.toString())).apply();home()})}
    private fun pinEntry(){val c=base("Sécurité");c.addView(tv("🔐 Entrez votre PIN",20,white,true));val p=input("PIN");p.inputType=2;c.addView(p);c.addView(btn("Déverrouiller"){if(hash(p.text.toString())==getSharedPreferences("settings",0).getString("pin",""))home()else toast("PIN incorrect")})}
    private fun changePin(){val c=base("Modifier le PIN");val o=input("Ancien PIN");val n=input("Nouveau PIN");o.inputType=2;n.inputType=2;c.addView(o);c.addView(n);c.addView(btn("Modifier"){val sp=getSharedPreferences("settings",0);if(hash(o.text.toString())!=sp.getString("pin","")){toast("Ancien PIN incorrect");return@btn};if(n.text.length!=4){toast("4 chiffres");return@btn};sp.edit().putString("pin",hash(n.text.toString())).apply();toast("PIN modifié");more()});nav()}

    private fun exportBackup(){
        try{
            val f=File(getExternalFilesDir(null),"seydou_abdou_backup.json");f.writeText(db.exportJson())
            val uri=FileProvider.getUriForFile(this,"${packageName}.fileprovider",f)
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="application/json";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},"Partager la sauvegarde"))
        }catch(e:Exception){toast("Export impossible")}
    }

    private fun pdfReceipt(invoice:String,client:String,items:List<SaleLine>,total:Long){
        try{
            val pdf=PdfDocument();val page=pdf.startPage(PdfDocument.PageInfo.Builder(595,842,1).create());val cv=page.canvas;val p=Paint().apply{color=Color.BLACK;isAntiAlias=true}
            p.textSize=18f;p.typeface=Typeface.DEFAULT_BOLD;cv.drawText("ENTREPRISE SEYDOU ABDOU",40f,50f,p)
            p.textSize=11f;p.typeface=Typeface.DEFAULT;cv.drawText("Matériaux de Construction & Équipements",40f,70f,p);cv.drawText("Guéchémé — Niger",40f,88f,p);cv.drawText("Reçu : $invoice",40f,110f,p);cv.drawText("Client : $client",40f,128f,p)
            var y=165f;p.typeface=Typeface.DEFAULT_BOLD;cv.drawText("Article",40f,y,p);cv.drawText("Qté",350f,y,p);cv.drawText("Total",455f,y,p);p.typeface=Typeface.DEFAULT;y+=24
            items.forEach{l->val m=db.material(l.materialId);cv.drawText(m.name.take(32),40f,y,p);cv.drawText(l.qty.toString(),350f,y,p);cv.drawText(money(l.qty*l.price),455f,y,p);y+=20}
            p.typeface=Typeface.DEFAULT_BOLD;p.textSize=16f;cv.drawText("TOTAL A PAYER : ${money(total)} FCFA",40f,800f,p);pdf.finishPage(page)
            val dir=File(getExternalFilesDir(null),"reçus");dir.mkdirs();val f=File(dir,"$invoice.pdf");FileOutputStream(f).use{pdf.writeTo(it)};pdf.close()
            val uri=FileProvider.getUriForFile(this,"${packageName}.fileprovider",f)
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="application/pdf";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},"Partager / imprimer le reçu"))
        }catch(e:Exception){toast("PDF impossible : ${e.message}")}
    }
    private fun about(){val c=base("À propos");c.addView(tv("ENTREPRISE SEYDOU ABDOU",22,white,true));c.addView(tv("Matériaux de Construction & Équipements\n📍 Guéchémé — Niger\n💰 FCFA\n\nGestion locale hors connexion : ventes, achats, stocks, clients, fournisseurs, dépenses, rapports, reçus PDF et sauvegarde.",15,muted));nav()}
}
