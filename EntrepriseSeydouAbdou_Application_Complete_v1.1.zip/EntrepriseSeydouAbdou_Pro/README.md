# ENTREPRISE SEYDOU ABDOU — Gestion Pro v1.1

Projet Android natif Kotlin, conçu comme une vraie application mobile de gestion commerciale hors connexion.

## Fonctions opérationnelles

### Ventes
- création de vente
- client, téléphone, localisation
- sélection des 22 matériaux
- quantité + prix unitaire
- contrôle du stock disponible
- transaction SQLite atomique
- diminution automatique du stock
- numéro de facture automatique
- reçu PDF
- partage / impression du PDF
- historique
- recherche facture/client
- détail d'une vente
- annulation d'une vente avec restauration du stock

### Stock
- stock persistant
- entrées de stock
- achats fournisseurs
- sorties/corrections d'inventaire
- seuil d'alerte
- historique des mouvements
- prix d'achat/prix courant

### Achats
- fournisseur
- articles, quantités, prix d'achat
- augmentation automatique du stock
- historique des achats

### Clients / fournisseurs
- création et consultation
- nom, téléphone, adresse/localisation

### Dépenses
- description
- catégorie
- montant
- historique

### Rapports
- chiffre d'affaires du jour
- dépenses du jour
- bénéfice du jour
- ventes du mois
- achats du mois
- dépenses du mois
- marge simplifiée du mois

### Sécurité
- PIN administrateur
- PIN haché en SHA-256
- verrouillage au démarrage

### Sauvegarde
- export JSON via le menu de partage Android
- données principales exportées pour sauvegarde

### Reçus
- PDF natif Android via PdfDocument
- identité de l'entreprise
- client
- articles
- quantités
- prix
- total FCFA
- partage/impression via Android FileProvider

## Données préchargées
Les 22 matériaux du prototype sont présents avec stock initial de 100 unités et seuil de 10. Les prix sont volontairement à 0 FCFA : aucun prix réel n'a été inventé.

## Identité
ENTREPRISE SEYDOU ABDOU
Matériaux de Construction & Équipements
Guéchémé — Niger
FCFA

## Compilation
Le projet cible Android 15 / API 35 et minimum Android 7.0 / API 24.

Ouvrir le dossier dans Android Studio puis :
Build > Generate App Bundle(s) / APK(s) > Generate APK(s)

Le binaire APK n'est pas inclus car l'environnement actuel ne dispose pas du SDK Android/Gradle nécessaires à la compilation.
